import { supabase } from '../lib/supabase';

// ==========================================
// AUTH API
// ==========================================

export const authAPI = {
  // Login de usuario
  async login(codigoInstitucion, email, password) {
    // Esta función se maneja en AuthContext
    // Este es solo un placeholder
    throw new Error('Usar useAuth().login() en su lugar');
  },

  // Login de admin
  async adminLogin(email, password) {
    throw new Error('Usar useAuth().adminLogin() en su lugar');
  }
};

// ==========================================
// SIGNUP API
// ==========================================

export const signupAPI = {
  // Verificar disponibilidad de slug
  async checkSlug(slug) {
    const { data, error } = await supabase
      .from('instituciones')
      .select('codigo')
      .eq('codigo', slug.toLowerCase())
      .maybeSingle();

    if (error) {
      throw new Error('Error al verificar disponibilidad');
    }

    return {
      disponible: !data,
      mensaje: data ? 'Este código ya está en uso' : 'Disponible'
    };
  },

  // Registrar nueva institución
  async register({ nombreInstitucion, slug, nombreKeymaster, emailKeymaster, password }) {
    // 1. Crear la institución
    const { data: institucion, error: instError } = await supabase
      .from('instituciones')
      .insert({
        nombre: nombreInstitucion,
        codigo: slug.toLowerCase(),
        plan: 'prueba',
        estado: 'activo',
        email_contacto: emailKeymaster
      })
      .select()
      .single();

    if (instError) {
      if (instError.code === '23505') { // Unique violation
        throw new Error('Este código de institución ya existe');
      }
      throw new Error('Error al crear la institución');
    }

    // 2. Crear el usuario KeyMaster
    // TODO: Hashear password con bcrypt en producción
    const { data: usuario, error: userError } = await supabase
      .from('usuarios')
      .insert({
        institucion_id: institucion.id,
        nombre: nombreKeymaster,
        email: emailKeymaster.toLowerCase(),
        password_hash: password, // En producción usar bcrypt
        rol: 'keymaster',
        activo: true,
        email_verificado: true // Por ahora auto-verificado para MVP
      })
      .select()
      .single();

    if (userError) {
      // Si falla el usuario, eliminar la institución
      await supabase.from('instituciones').delete().eq('id', institucion.id);
      throw new Error('Error al crear el usuario');
    }

    return {
      institucion,
      usuario: {
        id: usuario.id,
        email: usuario.email,
        nombre: usuario.nombre
      }
    };
  }
};

// ==========================================
// LEADS API
// ==========================================

export const leadsAPI = {
  // Listar leads de una institución
  async list(institucionId, filtros = {}) {
    let query = supabase
      .from('leads')
      .select('*, usuarios(nombre)')
      .eq('institucion_id', institucionId)
      .order('created_at', { ascending: false });

    // Aplicar filtros
    if (filtros.estado) {
      query = query.eq('estado', filtros.estado);
    }
    if (filtros.carrera) {
      query = query.eq('carrera_nombre', filtros.carrera);
    }
    if (filtros.asignado_a) {
      query = query.eq('asignado_a', filtros.asignado_a);
    }

    const { data, error } = await query;

    if (error) throw new Error('Error al cargar leads');
    return data;
  },

  // Crear lead
  async create(institucionId, leadData) {
    const { data, error } = await supabase
      .from('leads')
      .insert({
        institucion_id: institucionId,
        ...leadData
      })
      .select()
      .single();

    if (error) throw new Error('Error al crear lead');
    return data;
  },

  // Actualizar lead
  async update(leadId, updates) {
    const { data, error } = await supabase
      .from('leads')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', leadId)
      .select()
      .single();

    if (error) throw new Error('Error al actualizar lead');
    return data;
  },

  // Eliminar lead
  async delete(leadId) {
    const { error } = await supabase
      .from('leads')
      .delete()
      .eq('id', leadId);

    if (error) throw new Error('Error al eliminar lead');
    return true;
  },

  // Importar múltiples leads
  async importBulk(institucionId, leads) {
    const leadsConInstitucion = leads.map(lead => ({
      institucion_id: institucionId,
      ...lead
    }));

    const { data, error } = await supabase
      .from('leads')
      .insert(leadsConInstitucion)
      .select();

    if (error) throw new Error('Error al importar leads');
    return data;
  }
};

// ==========================================
// USUARIOS API
// ==========================================

export const usuariosAPI = {
  // Listar usuarios de una institución
  async list(institucionId) {
    const { data, error } = await supabase
      .from('usuarios')
      .select('*')
      .eq('institucion_id', institucionId)
      .order('created_at', { ascending: false });

    if (error) throw new Error('Error al cargar usuarios');
    return data;
  },

  // Crear usuario
  async create(institucionId, userData) {
    const { data, error } = await supabase
      .from('usuarios')
      .insert({
        institucion_id: institucionId,
        ...userData,
        password_hash: userData.password || '123456', // Password temporal
        password_temporal: true
      })
      .select()
      .single();

    if (error) {
      if (error.code === '23505') {
        throw new Error('Este email ya está registrado');
      }
      throw new Error('Error al crear usuario');
    }
    return data;
  },

  // Actualizar usuario
  async update(usuarioId, updates) {
    const { data, error } = await supabase
      .from('usuarios')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', usuarioId)
      .select()
      .single();

    if (error) throw new Error('Error al actualizar usuario');
    return data;
  },

  // Desactivar usuario
  async deactivate(usuarioId) {
    return this.update(usuarioId, { activo: false });
  }
};

// ==========================================
// INSTITUCIONES API (para SuperOwner)
// ==========================================

export const institucionesAPI = {
  // Listar todas las instituciones
  async list() {
    const { data, error } = await supabase
      .from('instituciones')
      .select('*, usuarios(count)')
      .neq('codigo', 'admitio-system') // Excluir la del sistema
      .order('created_at', { ascending: false });

    if (error) throw new Error('Error al cargar instituciones');
    return data;
  },

  // Actualizar plan de institución
  async updatePlan(institucionId, nuevoPlan) {
    const { data, error } = await supabase
      .from('instituciones')
      .update({ 
        plan: nuevoPlan,
        updated_at: new Date().toISOString()
      })
      .eq('id', institucionId)
      .select()
      .single();

    if (error) throw new Error('Error al actualizar plan');
    return data;
  },

  // Cambiar estado de institución
  async updateEstado(institucionId, nuevoEstado) {
    const { data, error } = await supabase
      .from('instituciones')
      .update({ 
        estado: nuevoEstado,
        updated_at: new Date().toISOString()
      })
      .eq('id', institucionId)
      .select()
      .single();

    if (error) throw new Error('Error al actualizar estado');
    return data;
  }
};

// ==========================================
// CARRERAS API
// ==========================================

export const carrerasAPI = {
  // Listar carreras de una institución
  async list(institucionId) {
    const { data, error } = await supabase
      .from('carreras')
      .select('*')
      .eq('institucion_id', institucionId)
      .eq('activa', true)
      .order('nombre');

    if (error) throw new Error('Error al cargar carreras');
    return data;
  },

  // Crear carrera
  async create(institucionId, carreraData) {
    const { data, error } = await supabase
      .from('carreras')
      .insert({
        institucion_id: institucionId,
        ...carreraData
      })
      .select()
      .single();

    if (error) throw new Error('Error al crear carrera');
    return data;
  }
};

// ==========================================
// ADMIN API (para SuperOwner)
// ==========================================

export const adminAPI = {
  // Dashboard con estadísticas generales
  async dashboard() {
    const { data: instituciones, error: instError } = await supabase
      .from('instituciones')
      .select('*')
      .neq('codigo', 'admitio-system');

    if (instError) throw new Error('Error al cargar estadísticas');

    const { count: totalLeads } = await supabase
      .from('leads')
      .select('*', { count: 'exact', head: true });

    const { count: totalUsuarios } = await supabase
      .from('usuarios')
      .select('*', { count: 'exact', head: true });

    // Calcular estadísticas por plan
    const porPlan = {
      prueba: instituciones.filter(i => i.plan === 'prueba').length,
      inicial: instituciones.filter(i => i.plan === 'inicial').length,
      profesional: instituciones.filter(i => i.plan === 'profesional').length,
      premium: instituciones.filter(i => i.plan === 'premium').length,
      enterprise: instituciones.filter(i => i.plan === 'enterprise').length,
    };

    return {
      totalTenants: instituciones.length,
      tenantsActivos: instituciones.filter(i => i.estado === 'activo').length,
      totalLeads: totalLeads || 0,
      totalUsuarios: totalUsuarios || 0,
      porPlan,
      crecimientoMensual: 0 // TODO: Calcular
    };
  },

  // Listar todos los tenants/instituciones
  async tenants() {
    const { data, error } = await supabase
      .from('instituciones')
      .select('*')
      .neq('codigo', 'admitio-system')
      .order('created_at', { ascending: false });

    if (error) throw new Error('Error al cargar instituciones');
    
    return data.map(inst => ({
      id: inst.id,
      nombre: inst.nombre,
      slug: inst.codigo,
      plan: inst.plan,
      activo: inst.estado === 'activo',
      leads: inst.leads_count || 0,
      usuarios: inst.usuarios_count || 0,
      created_at: inst.created_at,
      email: inst.email_contacto
    }));
  },

  // Obtener un tenant específico
  async getTenant(tenantId) {
    const { data: inst, error: instError } = await supabase
      .from('instituciones')
      .select('*')
      .eq('id', tenantId)
      .single();

    if (instError) throw new Error('Institución no encontrada');

    const { data: usuarios } = await supabase
      .from('usuarios')
      .select('*')
      .eq('institucion_id', tenantId);

    const { data: leads } = await supabase
      .from('leads')
      .select('*')
      .eq('institucion_id', tenantId);

    return {
      ...inst,
      slug: inst.codigo,
      activo: inst.estado === 'activo',
      usuarios: usuarios || [],
      leads: leads || [],
      stats: {
        totalLeads: leads?.length || 0,
        totalUsuarios: usuarios?.length || 0,
        leadsPorEstado: {
          nueva: leads?.filter(l => l.estado === 'nueva').length || 0,
          contactado: leads?.filter(l => l.estado === 'contactado').length || 0,
          seguimiento: leads?.filter(l => l.estado === 'seguimiento').length || 0,
          examen: leads?.filter(l => l.estado === 'examen').length || 0,
          matriculado: leads?.filter(l => l.estado === 'matriculado').length || 0,
        }
      }
    };
  },

  // Crear nuevo tenant
  async createTenant({ nombre, slug, plan, keymaster_nombre, keymaster_email }) {
    // 1. Crear institución
    const { data: inst, error: instError } = await supabase
      .from('instituciones')
      .insert({
        nombre,
        codigo: slug.toLowerCase(),
        plan: plan || 'prueba',
        estado: 'activo',
        email_contacto: keymaster_email
      })
      .select()
      .single();

    if (instError) {
      if (instError.code === '23505') {
        throw new Error('Este código ya está en uso');
      }
      throw new Error('Error al crear institución');
    }

    // 2. Crear KeyMaster
    const { error: userError } = await supabase
      .from('usuarios')
      .insert({
        institucion_id: inst.id,
        nombre: keymaster_nombre,
        email: keymaster_email.toLowerCase(),
        password_hash: '123456', // Password temporal
        rol: 'keymaster',
        activo: true,
        password_temporal: true
      });

    if (userError) {
      // Rollback: eliminar institución
      await supabase.from('instituciones').delete().eq('id', inst.id);
      throw new Error('Error al crear usuario KeyMaster');
    }

    return { id: inst.id, slug: inst.codigo };
  },

  // Actualizar tenant
  async updateTenant(tenantId, updates) {
    const supabaseUpdates = {};
    
    if (updates.nombre !== undefined) supabaseUpdates.nombre = updates.nombre;
    if (updates.plan !== undefined) supabaseUpdates.plan = updates.plan;
    if (updates.activo !== undefined) supabaseUpdates.estado = updates.activo ? 'activo' : 'suspendido';
    
    supabaseUpdates.updated_at = new Date().toISOString();

    const { data, error } = await supabase
      .from('instituciones')
      .update(supabaseUpdates)
      .eq('id', tenantId)
      .select()
      .single();

    if (error) throw new Error('Error al actualizar institución');
    return data;
  },

  // Eliminar tenant
  async deleteTenant(tenantId) {
    // Primero eliminar usuarios
    await supabase.from('usuarios').delete().eq('institucion_id', tenantId);
    // Luego leads
    await supabase.from('leads').delete().eq('institucion_id', tenantId);
    // Finalmente la institución
    const { error } = await supabase
      .from('instituciones')
      .delete()
      .eq('id', tenantId);

    if (error) throw new Error('Error al eliminar institución');
    return true;
  }
};

export default {
  auth: authAPI,
  signup: signupAPI,
  leads: leadsAPI,
  usuarios: usuariosAPI,
  instituciones: institucionesAPI,
  carreras: carrerasAPI,
  admin: adminAPI
};
