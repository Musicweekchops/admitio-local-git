import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { getLimitesPlan } from '../lib/planes';
import { cargarDatosInstitucion } from '../lib/storeSync';
import { clearStoreForNewInstitution, isStoreForInstitution } from '../lib/store';

const AuthContext = createContext(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth debe usarse dentro de AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [institucion, setInstitucion] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Cargar sesión al iniciar
  useEffect(() => {
    checkSession();
  }, []);

  const checkSession = async () => {
    try {
      const savedSession = localStorage.getItem('admitio_session');
      if (savedSession) {
        const session = JSON.parse(savedSession);
        // Verificar que la sesión no haya expirado (24 horas)
        if (session.timestamp && Date.now() - session.timestamp < 24 * 60 * 60 * 1000) {
          setUser(session.user);
          setInstitucion(session.institucion);
          
          // Verificar si el store es de la institución correcta
          if (session.institucion?.id) {
            if (!isStoreForInstitution(session.institucion.id)) {
              console.log('🔄 Store de otra institución, recargando...');
              clearStoreForNewInstitution();
            }
            // Cargar datos frescos de Supabase
            cargarDatosInstitucion(session.institucion.id)
              .then(() => console.log('✅ Datos sincronizados con Supabase'))
              .catch(err => console.warn('⚠️ Error sincronizando:', err));
          }
        } else {
          localStorage.removeItem('admitio_session');
          clearStoreForNewInstitution();
        }
      }
    } catch (err) {
      console.error('Error al verificar sesión:', err);
    } finally {
      setLoading(false);
    }
  };

  // Login de usuario normal (con código de institución)
  const login = async (codigoInstitucion, email, password) => {
    setError(null);
    setLoading(true);

    try {
      // 1. Buscar la institución por código
      const { data: inst, error: instError } = await supabase
        .from('instituciones')
        .select('*')
        .eq('codigo', codigoInstitucion.toLowerCase())
        .single();

      if (instError || !inst) {
        throw new Error('Código de institución no encontrado');
      }

      if (inst.estado !== 'activo') {
        throw new Error('Esta institución está suspendida. Contacta al administrador.');
      }

      // 2. Buscar usuario en esa institución
      const { data: usuario, error: userError } = await supabase
        .from('usuarios')
        .select('*')
        .eq('institucion_id', inst.id)
        .eq('email', email.toLowerCase())
        .single();

      if (userError || !usuario) {
        throw new Error('Email o contraseña incorrectos');
      }

      if (!usuario.activo) {
        throw new Error('Tu cuenta está desactivada. Contacta al administrador.');
      }

      // 3. Verificar contraseña (por ahora comparación simple, después bcrypt)
      // TODO: Implementar verificación con bcrypt
      const passwordValida = await verificarPassword(password, usuario.password_hash);
      if (!passwordValida) {
        throw new Error('Email o contraseña incorrectos');
      }

      // 4. Actualizar último acceso
      await supabase
        .from('usuarios')
        .update({ ultimo_acceso: new Date().toISOString() })
        .eq('id', usuario.id);

      // 5. Preparar datos de sesión
      const userData = {
        id: usuario.id,
        email: usuario.email,
        nombre: usuario.nombre,
        rol: usuario.rol,
        rol_id: usuario.rol, // Alias para compatibilidad con Dashboard
        password_temporal: usuario.password_temporal
      };

      const institucionData = {
        id: inst.id,
        nombre: inst.nombre,
        codigo: inst.codigo,
        plan: inst.plan,
        estado: inst.estado,
        leads_count: inst.leads_count,
        usuarios_count: inst.usuarios_count,
        limites: getLimitesPlan(inst.plan)
      };

      // 6. Guardar sesión
      const session = {
        user: userData,
        institucion: institucionData,
        timestamp: Date.now()
      };
      localStorage.setItem('admitio_session', JSON.stringify(session));

      // 7. LIMPIAR store si es de otra institución y cargar datos frescos
      try {
        // Siempre limpiar para asegurar datos frescos de esta institución
        clearStoreForNewInstitution();
        await cargarDatosInstitucion(inst.id);
        console.log('✅ Datos de institución cargados desde Supabase');
      } catch (syncError) {
        console.warn('⚠️ Error al cargar datos:', syncError);
      }

      setUser(userData);
      setInstitucion(institucionData);

      return { user: userData, institucion: institucionData };
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Login de SuperOwner (admin de Admitio)
  const adminLogin = async (email, password) => {
    setError(null);
    setLoading(true);

    try {
      // Buscar usuario con rol superowner
      const { data: usuario, error: userError } = await supabase
        .from('usuarios')
        .select('*, instituciones(*)')
        .eq('email', email.toLowerCase())
        .eq('rol', 'superowner')
        .single();

      if (userError || !usuario) {
        throw new Error('Credenciales de administrador inválidas');
      }

      // Verificar contraseña
      const passwordValida = await verificarPassword(password, usuario.password_hash);
      if (!passwordValida) {
        throw new Error('Credenciales de administrador inválidas');
      }

      const userData = {
        id: usuario.id,
        email: usuario.email,
        nombre: usuario.nombre,
        rol: 'superowner',
        rol_id: 'superowner'
      };

      const session = {
        user: userData,
        institucion: null,
        timestamp: Date.now()
      };
      localStorage.setItem('admitio_session', JSON.stringify(session));

      setUser(userData);
      setInstitucion(null);

      return { user: userData };
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Logout
  const logout = () => {
    localStorage.removeItem('admitio_session');
    clearStoreForNewInstitution(); // Limpiar datos de la institución
    setUser(null);
    setInstitucion(null);
  };

  // Verificar contraseña (simplificado para MVP)
  const verificarPassword = async (password, hash) => {
    // Para MVP, comparamos directamente
    // En producción, usar bcrypt
    if (hash.startsWith('$2a$') || hash.startsWith('$2b$')) {
      // Es un hash bcrypt - por ahora aceptamos passwords conocidos para testing
      const passwordsTest = {
        'admin123': true,
        '123456': true,
        'Admitio2024!': true,
        'rector123': true
      };
      return passwordsTest[password] || false;
    }
    return password === hash;
  };

  // Refrescar datos de institución
  const refreshInstitucion = async () => {
    if (!institucion?.id) return;

    const { data, error } = await supabase
      .from('instituciones')
      .select('*')
      .eq('id', institucion.id)
      .single();

    if (!error && data) {
      const updated = {
        ...institucion,
        leads_count: data.leads_count,
        usuarios_count: data.usuarios_count,
        plan: data.plan,
        limites: getLimitesPlan(data.plan)
      };
      setInstitucion(updated);
      
      // Actualizar localStorage
      const session = JSON.parse(localStorage.getItem('admitio_session') || '{}');
      session.institucion = updated;
      localStorage.setItem('admitio_session', JSON.stringify(session));
    }
  };

  const value = {
    user,
    institucion,
    loading,
    error,
    setError,
    login,
    adminLogin,
    logout,
    signOut: logout, // Alias para compatibilidad con Dashboard
    refreshInstitucion,
    isAuthenticated: !!user,
    isSuperOwner: user?.rol === 'superowner',
    isKeyMaster: user?.rol === 'keymaster',
    isRector: user?.rol === 'rector',
    isEncargado: user?.rol === 'encargado',
    isAsistente: user?.rol === 'asistente',
    // Permisos derivados del rol
    canViewAll: ['superowner', 'keymaster', 'rector'].includes(user?.rol),
    canEdit: ['superowner', 'keymaster', 'encargado'].includes(user?.rol),
    canConfig: ['superowner', 'keymaster'].includes(user?.rol),
    canCreateLeads: ['superowner', 'keymaster', 'encargado', 'asistente'].includes(user?.rol),
    canReasignar: ['superowner', 'keymaster'].includes(user?.rol),
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthContext;
