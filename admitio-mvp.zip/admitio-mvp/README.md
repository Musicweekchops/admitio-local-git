# 🎓 Admitio MVP

Sistema de Gestión de Admisiones para Instituciones Educativas.

## 🚀 Instalación

```bash
# Instalar dependencias
npm install

# Configurar variables de entorno
cp .env.example .env
# Editar .env con tus credenciales de Supabase

# Iniciar en desarrollo
npm run dev
```

## 🔑 Credenciales de Prueba

### SuperOwner (Tu panel de administración)
```
Email: owner@admitio.cl
Password: Admitio2024!
```

### Demo - KeyMaster ProJazz
```
Código: projazz
Email: admin@projazz.cl
Password: admin123
```

## 📁 Estructura

```
src/
├── App.jsx                 # Rutas y providers
├── main.jsx               # Entry point
├── index.css              # Estilos Tailwind
├── components/
│   ├── Icon.jsx           # Componente de iconos
│   └── UpgradeModal.jsx   # Modal de upgrade de plan
├── context/
│   └── AuthContext.jsx    # Estado de autenticación
├── lib/
│   ├── supabase.js        # Cliente Supabase
│   ├── planes.js          # Configuración de planes
│   ├── store.js           # Lógica de datos
│   └── ImportarCSV.jsx    # Importador de CSV
├── pages/
│   ├── Landing.jsx        # Página de inicio
│   ├── Login.jsx          # Login usuarios/admin
│   ├── Signup.jsx         # Registro instituciones
│   ├── Dashboard.jsx      # Dashboard principal
│   └── AdminDashboard.jsx # Panel SuperOwner
├── services/
│   └── api.js             # API con Supabase
└── data/
    └── mockData.js        # Datos de configuración
```

## 💳 Planes

| Plan | Leads | Usuarios | Precio |
|------|-------|----------|--------|
| Prueba | 15 | 1 | Gratis |
| Inicial | 300 | 5 | $79.990/año |
| Profesional | 1,500 | 15 | $149.990/año |
| Premium | 5,000 | 50 | $349.990/año |
| Enterprise | Custom | Custom | Cotización |

## 🔐 Modelo de UX

- **Explorar**: Gratis (usuarios pueden navegar todas las funciones)
- **Ejecutar**: Según plan (se valida al momento de la acción)
- **Upgrade**: Modal contextual con planes disponibles

## 🛠️ Tecnologías

- React 18
- Vite
- Tailwind CSS
- Supabase (PostgreSQL + Auth)
- Lucide Icons

## 📞 Soporte

Desarrollado por MWC Estudio - Santiago, Chile

---

**Versión:** 2.0 MVP  
**Última actualización:** Diciembre 2024
